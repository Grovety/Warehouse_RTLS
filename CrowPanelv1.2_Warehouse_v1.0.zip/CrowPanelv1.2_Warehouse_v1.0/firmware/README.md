# Firmware working directory

Place these files here before running or packaging CrowPanel P4 Fast Flasher:

- `flasher_args.json`;
- `bootloader.bin`;
- `partition-table.bin`;
- `Demo_for_P4.bin`.

All files must come from one ESP-IDF build directory for the intended
CrowPanel ESP32-P4 hardware revision. Never mix files from different builds or
hardware profiles.

The repository tracks this README and `flasher_args.json`. Local firmware
binaries are intentionally ignored by Git.
